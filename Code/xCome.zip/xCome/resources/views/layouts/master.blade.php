<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>xCome</title>

</head>
<body>
@yield('content')
</body>
</html>