<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>xCome</title>

</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>