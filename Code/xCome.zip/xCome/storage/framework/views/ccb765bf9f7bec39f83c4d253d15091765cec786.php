<?php $__env->startSection('content'); ?>
    <form action=<?php echo e(url("/register")); ?> method="post" novalidate>
        
        <?php echo e(csrf_field()); ?>

        <input type="email" name="email" placeholder="Email"><br>
        <input type="password" name="password" placeholder="Password"><br>
        <input type="password" name="retryPass" placeholder="Repeat Password"><br>
        <input type="name" name="name" placeholder="Name"><br>
        <input type="name" name="familyName" placeholder="Family"><br>
        <input type="name" name="username" placeholder="Username"><br>
        <input type="age" name="age" placeholder="age"><br>
        <input type="address" name="address" placeholder="address"><br>
        <input type="text" name="captcha" placeholder="captcha"><br>
        <input type="text" name="PersonID" placeholder="Person ID"><br>
        <input type="submit" value="register">

    </form>

    <?php if($check): ?>
        <p id="notValidate">input was wrong, please try again!</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>